A = [ 5 -9 6 ; 2 -7 4; 1 5 8];
B = [10.2 2.4 4.5; -2.3 7.7 11.1; -5.5 -3.2 0.9];
n1 = norm(A,1)
n2 = norm(A,2)
n3 = norm(A,Inf)
n1 = norm(B,1)
n2 = norm(B,2)
n3 = norm(B,Inf)