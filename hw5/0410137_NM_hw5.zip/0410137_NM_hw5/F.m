function dUdx = F(x,U)
dUdx = [U(2); -U(1)/4];